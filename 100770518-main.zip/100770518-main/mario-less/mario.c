#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int h;
    //Prompt for Height
    do
    {
        h = get_int("height: ");
    }
    //check if the conditions for height are met or not
    while (h > 8 || h < 1);
    //Loop for h times
    for (int i = 0; i < h; i++)
    {
        //loop for aligning #pyramid to the right
        for (int k = 0; k < h - i - 1; k++)
        {
            printf(" ");
        }
        for (int j = 0; j <= i; j++)
        {
            printf("#");
        }
        printf("\n");
    }

}