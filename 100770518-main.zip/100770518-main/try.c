#include <stdio.h>

 int main()
 {
    int a=1, b=2;
    float c =3.0, sum;
    sum = a + b + c;
    printf("sum : %d\n", sum);
 }